import React from 'react';

const modal = props => {
    return (
        <div>
            {props.children}
        </div>
    );
};


export default modal;